// // // // category_chip.dart
// // // // lib/features/spend_summary/view/widgets/category_chip.dart
// // // import 'package:flutter/material.dart';
// // // import 'package:flutter_screenutil/flutter_screenutil.dart';
// // // import 'package:google_fonts/google_fonts.dart';
// // // import '../../../../core/colors/app_colors.dart';
// // // import '../../model/category_model.dart';

// // // class CategoryChip extends StatelessWidget {
// // //   final CategoryModel category;
// // //   final bool isSelected;
// // //   final VoidCallback onTap;

// // //   const CategoryChip({
// // //     super.key,
// // //     required this.category,
// // //     required this.isSelected,
// // //     required this.onTap,
// // //   });

// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return GestureDetector(
// // //       onTap: onTap,
// // //       child: AnimatedContainer(
// // //         duration: const Duration(milliseconds: 200),
// // //         curve: Curves.easeInOut,
// // //         width: 78.w,
// // //         padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 6.w),
// // //         decoration: BoxDecoration(
// // //           color: isSelected
// // //               ? AppColors.primary.withOpacity(0.08)
// // //               : AppColors.card,
// // //           borderRadius: BorderRadius.circular(16.r),
// // //           border: Border.all(
// // //             color: isSelected ? AppColors.primary : AppColors.borderPrimary,
// // //             width: isSelected ? 1.5 : 0.8,
// // //           ),
// // //           boxShadow: isSelected
// // //               ? [
// // //                   BoxShadow(
// // //                     color: AppColors.primary.withOpacity(0.15),
// // //                     blurRadius: 12,
// // //                     offset: const Offset(0, 4),
// // //                   ),
// // //                 ]
// // //               : [
// // //                   BoxShadow(
// // //                     color: Colors.black.withOpacity(0.04),
// // //                     blurRadius: 6,
// // //                     offset: const Offset(0, 2),
// // //                   ),
// // //                 ],
// // //         ),
// // //         child: Column(
// // //           mainAxisSize: MainAxisSize.min,
// // //           children: [
// // //             // ── Icon container ──────────────────────────────────
// // //             Container(
// // //               width: 44.w,
// // //               height: 44.w,
// // //               decoration: BoxDecoration(
// // //                 gradient: LinearGradient(
// // //                   colors: category.gradientColors,
// // //                   begin: Alignment.topLeft,
// // //                   end: Alignment.bottomRight,
// // //                 ),
// // //                 borderRadius: BorderRadius.circular(12.r),
// // //               ),
// // //               child: Icon(category.icon, color: Colors.white, size: 20.sp),
// // //             ),

// // //             // ── Selected indicator dot ──────────────────────────
// // //             SizedBox(height: isSelected ? 4.h : 6.h),
// // //             if (isSelected)
// // //               Container(
// // //                 width: 5.w,
// // //                 height: 5.w,
// // //                 margin: EdgeInsets.only(bottom: 2.h),
// // //                 decoration: const BoxDecoration(
// // //                   color: AppColors.primary,
// // //                   shape: BoxShape.circle,
// // //                 ),
// // //               ),

// // //             // ── Name ───────────────────────────────────────────
// // //             Text(
// // //               category.name,
// // //               style: GoogleFonts.plusJakartaSans(
// // //                 fontSize: 11.sp,
// // //                 fontWeight: FontWeight.w500,
// // //                 color: isSelected
// // //                     ? AppColors.primaryLight
// // //                     : AppColors.textSecondary,
// // //               ),
// // //               maxLines: 1,
// // //               overflow: TextOverflow.ellipsis,
// // //             ),

// // //             SizedBox(height: 2.h),

// // //             // ── Amount ─────────────────────────────────────────
// // //             Text(
// // //               category.formattedAmount,
// // //               style: GoogleFonts.plusJakartaSans(
// // //                 fontSize: 11.sp,
// // //                 fontWeight: FontWeight.w700,
// // //                 color: isSelected ? AppColors.primary : AppColors.textPrimary,
// // //               ),
// // //             ),
// // //           ],
// // //         ),
// // //       ),
// // //     );
// // //   }
// // // }

// // // lib/features/spend_summary/view/widgets/category_chip.dart
// // import 'package:flutter/material.dart';
// // import 'package:flutter_screenutil/flutter_screenutil.dart';
// // import 'package:google_fonts/google_fonts.dart';
// // import '../../../../core/colors/app_colors.dart';
// // import '../../model/category_model.dart';

// // class CategoryChip extends StatelessWidget {
// //   final CategoryModel category;
// //   final bool isSelected;
// //   final VoidCallback onTap;

// //   const CategoryChip({
// //     super.key,
// //     required this.category,
// //     required this.isSelected,
// //     required this.onTap,
// //   });

// //   @override
// //   Widget build(BuildContext context) {
// //     return GestureDetector(
// //       onTap: onTap,
// //       child: AnimatedContainer(
// //         duration: const Duration(milliseconds: 200),
// //         curve: Curves.easeInOut,
// //         width: 78.w,
// //         // ✅ Fixed height — dot space always reserved, no layout shift
// //         height: 118.h,
// //         padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 6.w),
// //         decoration: BoxDecoration(
// //           color: isSelected
// //               ? AppColors.primary.withOpacity(0.08)
// //               : AppColors.card,
// //           borderRadius: BorderRadius.circular(16.r),
// //           border: Border.all(
// //             color: isSelected ? AppColors.primary : AppColors.borderPrimary,
// //             width: isSelected ? 1.5 : 0.8,
// //           ),
// //           boxShadow: isSelected
// //               ? [
// //                   BoxShadow(
// //                     color: AppColors.primary.withOpacity(0.15),
// //                     blurRadius: 12,
// //                     offset: const Offset(0, 4),
// //                   ),
// //                 ]
// //               : [
// //                   BoxShadow(
// //                     color: Colors.black.withOpacity(0.04),
// //                     blurRadius: 6,
// //                     offset: const Offset(0, 2),
// //                   ),
// //                 ],
// //         ),
// //         child: Column(
// //           mainAxisSize: MainAxisSize.min,
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             // ── Icon ───────────────────────────────────────────
// //             Container(
// //               width: 44.w,
// //               height: 44.w,
// //               decoration: BoxDecoration(
// //                 gradient: LinearGradient(
// //                   colors: category.gradientColors,
// //                   begin: Alignment.topLeft,
// //                   end: Alignment.bottomRight,
// //                 ),
// //                 borderRadius: BorderRadius.circular(12.r),
// //               ),
// //               child: Icon(category.icon, color: Colors.white, size: 20.sp),
// //             ),

// //             SizedBox(height: 5.h),

// //             // ── Dot slot — ALWAYS takes space, just invisible when unselected
// //             AnimatedContainer(
// //               duration: const Duration(milliseconds: 200),
// //               width: 5.w,
// //               height: 5.w,
// //               margin: EdgeInsets.only(bottom: 3.h),
// //               decoration: BoxDecoration(
// //                 color: isSelected ? AppColors.primary : Colors.transparent,
// //                 shape: BoxShape.circle,
// //               ),
// //             ),

// //             // ── Name ───────────────────────────────────────────
// //             Text(
// //               category.name,
// //               style: GoogleFonts.plusJakartaSans(
// //                 fontSize: 11.sp,
// //                 fontWeight: FontWeight.w500,
// //                 color: isSelected
// //                     ? AppColors.primaryLight
// //                     : AppColors.textSecondary,
// //               ),
// //               maxLines: 1,
// //               overflow: TextOverflow.ellipsis,
// //             ),

// //             SizedBox(height: 2.h),

// //             // ── Amount ─────────────────────────────────────────
// //             Text(
// //               category.formattedAmount,
// //               style: GoogleFonts.plusJakartaSans(
// //                 fontSize: 11.sp,
// //                 fontWeight: FontWeight.w700,
// //                 color: isSelected ? AppColors.primary : AppColors.textPrimary,
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }

// // lib/features/spend_summary/view/widgets/category_chip.dart
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:google_fonts/google_fonts.dart';
// import '../../../../core/colors/app_colors.dart';
// import '../../model/category_model.dart';

// class CategoryChip extends StatelessWidget {
//   final CategoryModel category;
//   final bool isSelected;
//   final VoidCallback onTap;

//   const CategoryChip({
//     super.key,
//     required this.category,
//     required this.isSelected,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: AnimatedContainer(
//         duration: const Duration(milliseconds: 200),
//         curve: Curves.easeInOut,
//         width: 78.w,
//         padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 6.w),
//         decoration: BoxDecoration(
//           color: isSelected
//               ? AppColors.primary.withOpacity(0.08)
//               : AppColors.card,
//           borderRadius: BorderRadius.circular(16.r),
//           border: Border.all(
//             color: isSelected ? AppColors.primary : AppColors.borderPrimary,
//             width: isSelected ? 1.5 : 0.8,
//           ),
//           boxShadow: isSelected
//               ? [
//                   BoxShadow(
//                     color: AppColors.primary.withOpacity(0.15),
//                     blurRadius: 12,
//                     offset: const Offset(0, 4),
//                   ),
//                 ]
//               : [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.04),
//                     blurRadius: 6,
//                     offset: const Offset(0, 2),
//                   ),
//                 ],
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             // Icon
//             Container(
//               width: 44.w,
//               height: 44.w,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   colors: category.gradientColors,
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                 ),
//                 borderRadius: BorderRadius.circular(12.r),
//               ),
//               child: Icon(category.icon, color: Colors.white, size: 20.sp),
//             ),

//             SizedBox(height: 5.h),

//             // Dot — ALWAYS rendered, transparent when unselected
//             // Height stays constant → no layout shift → no overflow
//             AnimatedContainer(
//               duration: const Duration(milliseconds: 200),
//               width: 5.w,
//               height: 5.w,
//               margin: EdgeInsets.only(bottom: 3.h),
//               decoration: BoxDecoration(
//                 color: isSelected ? AppColors.primary : Colors.transparent,
//                 shape: BoxShape.circle,
//               ),
//             ),

//             // Name
//             Text(
//               category.name,
//               style: GoogleFonts.plusJakartaSans(
//                 fontSize: 11.sp,
//                 fontWeight: FontWeight.w500,
//                 color: isSelected
//                     ? AppColors.primaryLight
//                     : AppColors.textSecondary,
//               ),
//               maxLines: 1,
//               overflow: TextOverflow.ellipsis,
//             ),

//             SizedBox(height: 2.h),

//             // Amount
//             Text(
//               category.formattedAmount,
//               style: GoogleFonts.plusJakartaSans(
//                 fontSize: 11.sp,
//                 fontWeight: FontWeight.w700,
//                 color: isSelected ? AppColors.primary : AppColors.textPrimary,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// lib/features/spend_summary/view/widgets/category_chip.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/colors/app_colors.dart';
import '../../model/category_model.dart';

class CategoryChip extends StatelessWidget {
  final CategoryModel category;
  final bool isSelected;
  final VoidCallback onTap;

  const CategoryChip({
    super.key,
    required this.category,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        width: 82.w,
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 10.w),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(14.r),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.borderPrimary,
            width: isSelected ? 1.5 : 1.0,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.22),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // ── Icon — flat, no gradient bg when selected ────────
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.18)
                    : _iconBgColor(category.gradientColors),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Icon(
                category.icon,
                color: isSelected ? Colors.white : category.gradientColors.last,
                size: 18.sp,
              ),
            ),

            SizedBox(height: 8.h),

            // ── Name ─────────────────────────────────────────────
            Text(
              category.name,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.sp,
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.white : AppColors.textSecondary,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 3.h),

            // ── Amount ───────────────────────────────────────────
            Text(
              category.formattedAmount,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.sp,
                fontWeight: FontWeight.w700,
                color: isSelected
                    ? Colors.white.withOpacity(0.90)
                    : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Soft tinted background for the icon — no bright gradient
  Color _iconBgColor(List<Color> gradient) {
    return gradient.first.withOpacity(0.10);
  }
}
