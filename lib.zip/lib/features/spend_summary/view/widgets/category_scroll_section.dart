// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:google_fonts/google_fonts.dart';
// import '../../../../core/colors/app_colors.dart';
// import '../../../../core/constants/app_strings.dart';
// import '../../controller/spend_summary_controller.dart';
// import 'category_chip.dart';

// class CategoryScrollSection extends StatelessWidget {
//   const CategoryScrollSection({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final controller = Get.find<SpendSummaryController>();

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Header
//         Padding(
//           padding: EdgeInsets.symmetric(horizontal: 16.w),
//           child: Row(
//             children: [
//               Text(
//                 AppStrings.categories,
//                 style: GoogleFonts.plusJakartaSans(
//                   fontSize: 16.sp,
//                   fontWeight: FontWeight.w700,
//                   color: AppColors.textPrimary,
//                 ),
//               ),
//               const Spacer(),
//               Obx(
//                 () => Container(
//                   padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
//                   decoration: BoxDecoration(
//                     color: AppColors.primary.withOpacity(0.08),
//                     borderRadius: BorderRadius.circular(8.r),
//                     border: Border.all(
//                       color: AppColors.primary.withOpacity(0.20),
//                     ),
//                   ),
//                   child: Text(
//                     '${controller.categories.length - 1} types',
//                     style: GoogleFonts.plusJakartaSans(
//                       fontSize: 11.sp,
//                       fontWeight: FontWeight.w600,
//                       color: AppColors.primaryLight,
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),

//         SizedBox(height: 12.h),

//         Obx(() {
//           return Padding(
//             padding: EdgeInsets.only(bottom: 4.h),
//             child: SizedBox(
//               height: 128.h,
//               child: ListView.builder(
//                 scrollDirection: Axis.horizontal,
//                 physics: const BouncingScrollPhysics(),
//                 clipBehavior: Clip.none, // shadow/edges clip nahi hoge
//                 padding: EdgeInsets.only(
//                   left: 16.w,
//                   right: 8.w,
//                   top: 4.h,
//                   bottom: 4.h,
//                 ),
//                 itemCount: controller.categories.length,
//                 itemBuilder: (ctx, i) {
//                   final cat = controller.categories[i];
//                   return Padding(
//                     padding: EdgeInsets.only(right: 10.w),
//                     child: Obx(
//                       () => CategoryChip(
//                         category: cat,
//                         isSelected:
//                             controller.selectedCategory.value == cat.name,
//                         onTap: () => controller.selectCategory(cat.name),
//                       ),
//                     ),
//                   );
//                 },
//               ),
//             ),
//           );
//         }),
//       ],
//     );
//   }
// }

// lib/features/spend_summary/view/widgets/category_scroll_section.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/colors/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../controller/spend_summary_controller.dart';
import 'category_chip.dart';

class CategoryScrollSection extends StatelessWidget {
  const CategoryScrollSection({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SpendSummaryController>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Section Header ───────────────────────────────────────
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                AppStrings.categories,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                  letterSpacing: -0.2,
                ),
              ),
              const Spacer(),
              Obx(
                () => Text(
                  '${controller.categories.length - 1} types',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textHint,
                  ),
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 12.h),

        // ── Horizontal Scroll ────────────────────────────────────
        Obx(() {
          return SizedBox(
            height: 118.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              clipBehavior: Clip.none,
              padding: EdgeInsets.only(
                left: 16.w,
                right: 8.w,
                top: 2.h,
                bottom: 4.h,
              ),
              itemCount: controller.categories.length,
              itemBuilder: (ctx, i) {
                final cat = controller.categories[i];
                return Padding(
                  padding: EdgeInsets.only(right: 8.w),
                  child: Obx(
                    () => CategoryChip(
                      category: cat,
                      isSelected: controller.selectedCategory.value == cat.name,
                      onTap: () => controller.selectCategory(cat.name),
                    ),
                  ),
                );
              },
            ),
          );
        }),
      ],
    );
  }
}
